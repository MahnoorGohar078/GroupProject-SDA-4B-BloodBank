﻿namespace BloodBank.PLL
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.donor = new System.Windows.Forms.Button();
            this.feedback = new System.Windows.Forms.Button();
            this.ButtonAccount = new System.Windows.Forms.Button();
            this.buttonLogin = new System.Windows.Forms.Button();
            this.about = new System.Windows.Forms.Button();
            this.hospitals = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Button();
            this.textboxPassword = new System.Windows.Forms.TextBox();
            this.textboxUser = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(233)))));
            this.panel2.Controls.Add(this.donor);
            this.panel2.Controls.Add(this.feedback);
            this.panel2.Controls.Add(this.ButtonAccount);
            this.panel2.Controls.Add(this.buttonLogin);
            this.panel2.Controls.Add(this.about);
            this.panel2.Controls.Add(this.hospitals);
            this.panel2.Controls.Add(this.search);
            this.panel2.Controls.Add(this.textboxPassword);
            this.panel2.Controls.Add(this.textboxUser);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(2, 80);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(858, 418);
            this.panel2.TabIndex = 3;
            // 
            // donor
            // 
            this.donor.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donor.Location = new System.Drawing.Point(726, 3);
            this.donor.Name = "donor";
            this.donor.Size = new System.Drawing.Size(124, 49);
            this.donor.TabIndex = 12;
            this.donor.Text = "Registered Donors";
            this.donor.UseVisualStyleBackColor = true;
            this.donor.Click += new System.EventHandler(this.donor_Click);
            // 
            // feedback
            // 
            this.feedback.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feedback.Location = new System.Drawing.Point(604, 3);
            this.feedback.Name = "feedback";
            this.feedback.Size = new System.Drawing.Size(116, 49);
            this.feedback.TabIndex = 11;
            this.feedback.Text = "Feedback";
            this.feedback.UseVisualStyleBackColor = true;
            this.feedback.Click += new System.EventHandler(this.feedback_Click);
            // 
            // ButtonAccount
            // 
            this.ButtonAccount.BackColor = System.Drawing.Color.Red;
            this.ButtonAccount.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAccount.Location = new System.Drawing.Point(356, 316);
            this.ButtonAccount.Name = "ButtonAccount";
            this.ButtonAccount.Size = new System.Drawing.Size(193, 42);
            this.ButtonAccount.TabIndex = 10;
            this.ButtonAccount.Text = "New Account";
            this.ButtonAccount.UseVisualStyleBackColor = false;
            this.ButtonAccount.Click += new System.EventHandler(this.ButtonAccount_Click);
            // 
            // buttonLogin
            // 
            this.buttonLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonLogin.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogin.Location = new System.Drawing.Point(356, 249);
            this.buttonLogin.Name = "buttonLogin";
            this.buttonLogin.Size = new System.Drawing.Size(193, 43);
            this.buttonLogin.TabIndex = 9;
            this.buttonLogin.Text = "Login To Profile";
            this.buttonLogin.UseVisualStyleBackColor = false;
            this.buttonLogin.Click += new System.EventHandler(this.buttonLogin_Click);
            // 
            // about
            // 
            this.about.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.about.Location = new System.Drawing.Point(491, 3);
            this.about.Name = "about";
            this.about.Size = new System.Drawing.Size(107, 49);
            this.about.TabIndex = 8;
            this.about.Text = "About";
            this.about.UseVisualStyleBackColor = true;
            this.about.Click += new System.EventHandler(this.about_Click);
            // 
            // hospitals
            // 
            this.hospitals.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hospitals.Location = new System.Drawing.Point(378, 3);
            this.hospitals.Name = "hospitals";
            this.hospitals.Size = new System.Drawing.Size(107, 49);
            this.hospitals.TabIndex = 7;
            this.hospitals.Text = "Nearby Hospitals";
            this.hospitals.UseVisualStyleBackColor = true;
            this.hospitals.Click += new System.EventHandler(this.hospitals_Click);
            // 
            // search
            // 
            this.search.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.Location = new System.Drawing.Point(265, 3);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(107, 49);
            this.search.TabIndex = 6;
            this.search.Text = "Search Donor";
            this.search.UseVisualStyleBackColor = true;
            // 
            // textboxPassword
            // 
            this.textboxPassword.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxPassword.Location = new System.Drawing.Point(265, 207);
            this.textboxPassword.Name = "textboxPassword";
            this.textboxPassword.Size = new System.Drawing.Size(356, 25);
            this.textboxPassword.TabIndex = 3;
            this.textboxPassword.TextChanged += new System.EventHandler(this.textboxPassword_TextChanged);
            // 
            // textboxUser
            // 
            this.textboxUser.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxUser.Location = new System.Drawing.Point(265, 135);
            this.textboxUser.Name = "textboxUser";
            this.textboxUser.Size = new System.Drawing.Size(356, 25);
            this.textboxUser.TabIndex = 2;
            this.textboxUser.TextChanged += new System.EventHandler(this.textboxUser_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(154, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Password";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(151, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Username";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(0)))), ((int)(((byte)(8)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(858, 72);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "BloodBank";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 501);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button about;
        private System.Windows.Forms.Button hospitals;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.TextBox textboxPassword;
        private System.Windows.Forms.TextBox textboxUser;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ButtonAccount;
        private System.Windows.Forms.Button buttonLogin;
        private System.Windows.Forms.Button feedback;
        private System.Windows.Forms.Button donor;
    }
}
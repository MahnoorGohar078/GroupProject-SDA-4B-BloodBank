﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BloodBank.BLL;

namespace BloodBank.PLL
{
    public partial class Profile : Form
    {
        string connectionString = @"Data Source=DESKTOP-CCBV35A\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True";
        SqlDataAdapter adp;
        DataTable dt;
        public Profile()
        {
            InitializeComponent();
        }

        private void profile1_Click(object sender, EventArgs e)
        {
            showdata();
        }

        public void showdata()
        {
            adp = new SqlDataAdapter("select * from registration" , connectionString);
            dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Profile_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bloodBankDataSet1.Registration' table. You can move, or remove it, as needed.
            this.registrationTableAdapter.Fill(this.bloodBankDataSet1.Registration);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

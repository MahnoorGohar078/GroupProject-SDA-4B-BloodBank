﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BloodBank.BLL;
using System.Data.SqlClient;

namespace BloodBank.PLL
{
    public partial class Registration : Form
    {
        string connectionString = @"Data Source=DESKTOP-CCBV35A\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True";
        //Connection con = new Connection();
        public Registration()
        {
            InitializeComponent();
        }

        private void register_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Please Fill Mandatory Fields");
            }

            else if (textBox5.Text != textBox6.Text)
            {
                MessageBox.Show("Your Passwords do not match");
            }
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("Register", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("ID", textBox13.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("FirstName", textBox1.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("LastName", textBox2.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("UserName", textBox3.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("EmailID", textBox4.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("Password", textBox5.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("BloodGroup", comboBox1.Text);
                    sqlCmd.Parameters.AddWithValue("Gender", textBox7.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("Age", textBox8.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("ContactNo", textBox9.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("Address", textBox10.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("Area", textBox11.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("City", textBox12.Text.Trim());
                    sqlCmd.ExecuteNonQuery();

                    MessageBox.Show("YOU HAVE BEEN REGISTERED AS DONOR SUCCESSFULLY..");
                    clear();
                }
            }
        }
        void clear()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = comboBox1.Text = textBox7.Text = textBox8.Text = textBox9.Text = textBox10.Text = textBox11.Text = textBox12.Text = textBox13.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Registration_Load(object sender, EventArgs e)
        {

        }
    }
}

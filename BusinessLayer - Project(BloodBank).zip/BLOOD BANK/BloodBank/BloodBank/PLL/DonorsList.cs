﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BloodBank.BLL;

namespace BloodBank.PLL
{
    public partial class DonorsList : Form
    {
        string connectionString = @"Data Source=DESKTOP-CCBV35A\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True";
        SqlDataAdapter adp;
        DataTable dt;
        public DonorsList()
        {
            InitializeComponent();
        }

        private void donorlist_Click(object sender, EventArgs e)
        {


            showdata();
        }

        public void showdata()
        {
            adp = new SqlDataAdapter("select * from registration", connectionString);
            dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void DonorsList_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bloodBankDataSet.Registration' table. You can move, or remove it, as needed.
            this.registrationTableAdapter.Fill(this.bloodBankDataSet.Registration);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }
    }
}     
